 var typed = new Typed(".auto-input-name",{
                        strings: ["CV", "RESUME", "CURRICULUM VITAE"],
                        typeSpeed: 100,
                        backSpeed: 100,
                        loop: true,
                    });